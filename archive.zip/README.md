# 2022-OasisDigital-Intern-Project
This is the Git Repo for the intern group at Oasis Digital working on making an "aim-lab" style game.
